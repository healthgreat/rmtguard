# RMTGuard Author Confirmation Delivery Bundle

Generated: 2026-05-12

## Purpose

This ZIP contains only the files needed to ask the corresponding authors to
confirm author-controlled manuscript items before any v0.1.1 release, Zenodo
archive refresh, or editor-facing presubmission inquiry.

## What To Send First

1. Send `01_author_declaration_confirmation_packet.docx`.
2. Copy the text from `02_wechat_copy_paste_draft.md` into WeChat, or use
   `03_email_draft.md` / `04_email_draft.eml` if email is preferred.
3. Ask authors to reply in writing. A verbal approval is not enough for the
   local release gate.

## Items Needing Confirmation

- Postal code: author-provided 350000 versus public-source candidate 210019.
- CRediT author roles.
- Funding statement.
- Competing interests statement.
- Ethics / public-data-use statement.
- Figure 4 bounded wording.
- Nature reporting-summary items.
- Title-page author order, affiliation, emails, and ORCID records.

## Stop Rules

- Do not submit to a journal yet.
- Do not create a v0.1.1 GitHub Release or Zenodo archive yet.
- Do not send the Nature Methods presubmission inquiry yet.
- Stop and update the manuscript package if any author changes funding,
  competing interests, authorship, affiliation, ORCID, or Figure 4 wording.

## After Replies Arrive

1. Save replies under `metadata/author_reply_evidence/`.
2. Follow `05_reply_intake_runbook.md`.
3. Re-run the author declaration packet, v0.1.1 preflight, dashboard, evidence
   freeze, Gantt, and shared export.
